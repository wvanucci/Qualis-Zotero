from .core import processar, processar_com_config
from .config import load_config

__all__ = ["processar", "load_config", "processar_com_config"]